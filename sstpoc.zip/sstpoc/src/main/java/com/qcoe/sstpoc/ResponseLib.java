package com.qcoe.sstpoc;

import java.io.IOException;
import java.io.InputStream;


public class ResponseLib {

    public static String contactForm(String req) {
        String tt = "Hi Duncan";
        String uu = "You sent: " + req + " A bit added on: " + tt;
        return uu;
    }

    public static String alive() throws IOException {
        String templateRequired = "/jsonTemplates/simple.json";
        Class localClass = Main.class;
        InputStream inputStream = localClass.getResourceAsStream(templateRequired);
        String resp = Utils.readTemplate(inputStream);
        return resp;
    }

}
