package com.qcoe.sstpoc;

import org.jtwig.JtwigModel;
import org.jtwig.JtwigTemplate;


public class Transform {


    public static String demo() {

        int respCode = 655443;
        String respPay = "Some Nonsense Or Another, right?";

        JtwigTemplate template = JtwigTemplate.classpathTemplate("jsonTemplates/demo.twig");
        JtwigModel model = JtwigModel.newModel()
                .with("responseCode", respCode)
                .with("responsePayload", respPay);

        return(template.render(model));

    }

}
