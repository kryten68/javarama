package com.qcoe.sstpoc;

import static spark.Spark.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;

public class Main {

    public static void main(String[] args) {

        port(8080);
        Logger logger = LoggerFactory.getLogger("eventLog");


        // .Set the location to serve static files from:
        staticFiles.location("/web");
        init();

        get("/qcoe", (request, response) -> {
            response.status(302);
            response.redirect("qcoe.html");
            return null;
        });

        get( "/contactForm", (request, response) -> {
            logger.info(LocalDateTime.now().toString() + " method:get, url:contactForm");
            return "OK";
        });

        post( "/contactForm", (request, response) -> {
            String bb = request.body();
            logger.info("Got " + bb);
            return(ResponseLib.contactForm(bb));
        });

        get("/alive", (request, response) -> {
            response.type("Application/json");
            return(ResponseLib.alive());
        });

        get("/testTransform", (request, response) -> {
            response.type("Application/json");
            String a = Transform.demo();
            return a;
        });

        get("/starships", (request, response) -> {
            String craft = "starships";
            String resp = Lookups.craft();
            return resp;
        });



    }
}
