package com.qcoe.sstpoc;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.io.IOException;


public class Lookups {

    public static String craft() throws IOException {

        String url = "https://swapi.co/api/starships";
        String resp = Lookups.get(url);
        return resp;
    }

    public static String get(String url) throws IOException {

        String resp;
        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();

        try (Response response = client.newCall(request).execute()) {
            resp = response.body().string();
        }
        return resp;
    }
}