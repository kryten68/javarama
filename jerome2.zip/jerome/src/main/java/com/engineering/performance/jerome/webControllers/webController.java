package com.engineering.performance.jerome.webControllers;

import com.engineering.performance.jerome.generators.Generators;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class webController {

    @RequestMapping(value="/demoPage", method=RequestMethod.GET)
    public String demoPage(Model model) {

        model.addAttribute("placeHolderOne", "This is a H1 header");
        model.addAttribute("blurb", Generators.blurb.getParagraph());
        return "templateExample";
    }
}
