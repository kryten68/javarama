package com.engineering.performance.jerome.generators;




public class performanceTest {

    private String testName;
    private String testTool;

    private int virtualUsers;
    private int durationMins;
    private int transactionNumbers;
    private int numberInjectors;

    public String getTestName() {
        return testName;
    }

    public void setTestName(String testName) {
        this.testName = testName;
    }

    public String getTestTool() {
        return testTool;
    }

    public void setTestTool(String testTool) {
        this.testTool = testTool;
    }

    public int getVirtualUsers() {
        return virtualUsers;
    }

    public void setVirtualUsers(int virtualUsers) {
        this.virtualUsers = virtualUsers;
    }

    public int getDurationMins() {
        return durationMins;
    }

    public void setDurationMins(int durationMins) {
        this.durationMins = durationMins;
    }

    public int getTransactionNumbers() {
        return transactionNumbers;
    }

    public void setTransactionNumbers(int transactionNumbers) {
        this.transactionNumbers = transactionNumbers;
    }

    public int getNumberInjectors() {
        return numberInjectors;
    }

    public void setNumberInjectors(int numberInjectors) {
        this.numberInjectors = numberInjectors;
    }


}
