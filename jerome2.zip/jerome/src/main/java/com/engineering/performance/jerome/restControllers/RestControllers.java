package com.engineering.performance.jerome.restControllers;


import com.engineering.performance.jerome.generators.performanceTest;
import com.engineering.performance.jerome.http.Methods;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestControllers {

    @RequestMapping(value="/restApi_1", method=RequestMethod.GET)
    public String restApi1() {

        return "Got restApi 1";

    }

    @RequestMapping(value="/restApi_2", method=RequestMethod.GET)
    public String restApi2() {

        return "Got restApi 2";

    }

    @RequestMapping(value="/performanceTest", method=RequestMethod.GET, produces="Application/json")
    public performanceTest performanceTest() {

        performanceTest pt = new performanceTest();
        pt.setTestName("Open Banking");
        pt.setTestTool("Jmeter");
        pt.setDurationMins(120);
        pt.setNumberInjectors(8);
        pt.setVirtualUsers(360);
        pt.setTransactionNumbers(48000);
        return pt;

    }

    @RequestMapping(value="/testGet", method=RequestMethod.GET)
    public void testGet() {

        String url = "https://swapi.co/api/people/4";
        Methods http = new Methods();
        Object resp = http.get(url);
        System.out.println(resp);

    }

    @RequestMapping(value="/testPost", method=RequestMethod.POST)
    public void testPost() {

        System.out.println("Made it to the Post method");
        String url = "https://reqres.in/api/users";
        String body = "{ \"name\":\"neo\",\"job\":\"the one\"}";

        Methods http = new Methods();
        http.post(url, body);

        //Object resp = http.post(url, body);
        //System.out.println(resp);

    }

    @RequestMapping(value="/callaPost", method=RequestMethod.GET)
    public String callPost() {
        String tt = "done";
        String uri = "https://httpbin.org/post";
        String payload = "{ \"fieldOne\":\"Mary\", \"fieldTwo\": \"Poppins\" }";
        Methods http = new Methods();
        String resp = http.post(uri, payload);
        return resp;
    }

}
