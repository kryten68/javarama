package com.engineering.performance.jerome.http;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;


public class Methods {

    public String userAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 10_3_1 like Mac OS X) AppleWebKit/603.1.30 (KHTML, like Gecko) Version/10.0 Mobile/14E304 Safari/602.1";

    // Generic get helper method
    public Object get(String url) {

        RestTemplate httpGet = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.add("user-agent", userAgent);
        HttpEntity<String> entity = new HttpEntity<String>("parameters", headers);
        ResponseEntity<String> result = httpGet.exchange(url, HttpMethod.GET, entity, String.class);
        return result;
    }

    public String post(String url, String body) {

        System.out.println("Post has received url: " + url + " and body: " + body);
        RestTemplate httpPost = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();

        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("user-agent", userAgent);
        HttpEntity<String> entity = new HttpEntity<String>(body, headers);
        ResponseEntity<String> response = httpPost.exchange(url, HttpMethod.POST, entity, String.class);

        String resp = response.getBody();
        System.out.println(resp);
        return resp;

    }

}
