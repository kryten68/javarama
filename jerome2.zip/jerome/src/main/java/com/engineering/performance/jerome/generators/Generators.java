package com.engineering.performance.jerome.generators;

import java.util.Random;


public class Generators {

    public static class blurb {

        public static String getParagraph() {

            String blurb;
            Random random = new Random();
            int r = random.nextInt(10) + 1;

            // Less than 10
            if (r < 5) {

                blurb = "This is just a block of paragraph blurb which has been returned due to a random number" +
                        " between 1 and 10 being less than 5, this time around. " +
                        "The number in question was actually: " + r;

            } else if ( r == 5) {

                blurb = "This is just a block of paragraph blurb which has been returned due to a random number" +
                        " between 1 and 10 being returned as exactly: " + r;

            } else {

                blurb = "This is just a block of paragraph blurb which has been returned due to a random number" +
                        " between 1 and 10 being higher than 5, this time around. " +
                        "The number in question was actually: " + r;
            }

            return blurb;
        }
    }
}


