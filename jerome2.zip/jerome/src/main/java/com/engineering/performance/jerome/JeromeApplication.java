package com.engineering.performance.jerome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JeromeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JeromeApplication.class, args);
	}

}
