/*
. ====================================================================================
. ..............THIS EXECUTES ON PAGE LOAD
. Hit the spark endpoint to trigger the call to the external endpoint to get data
. JQuery is loaded by this application so we may as well use that...
. ====================================================================================
*/

// Hit back end spark to ask for the starship data
// Ajax request ID: 001
$.ajax({
    url: 'http://localhost:8080/starships',
    error: function () {
        console.log(">>> Inside Ajax ID: 001");
        console.log(">>> Error callback has been triggered.");
    },
    success: function (data) {
        processIncomingStarshipData(data);
    },
    type: 'get'
});

/*
. ..............EVERYTHING ABOVE HERE EXECUTES ON PAGE LOAD
. ====================================================================================
*/

function processIncomingStarshipData(data) {

    let parsedResult = $.parseJSON(data);
    let results = parsedResult.results;
    let resLen = results.length;
    let arrLen = resLen - 1;
    shipNameArr = [];
    shipLenArr = [];

    // Diagram Settings:
    let diagramSettings = new Object();
    diagramSettings.textLabel = "Star Wars Spacecraft Lengths";
    diagramSettings.bgColor = '#5F93A7';
    diagramSettings.borderColor = "rgb(255, 99, 132)";
    // ...

    for (i = 0; i < resLen; i++) {
        var name = results[i].name;
        var length = results[i].length;
        shipNameArr.push(name);
        shipLenArr.push(Number(length));
    }

    // Call To Render:
    renderChart(shipNameArr, shipLenArr, diagramSettings);
}

function renderChart(dataNames, dataValues, diagramSettings) {

    var ctx = document.getElementById('main_chart_one').getContext('2d');
    var chart = new Chart(ctx, {
        // The type of chart we want to create
        type: 'bar',
        data: {
            labels: dataNames,
            datasets: [{
                label: diagramSettings.textLabel,
                backgroundColor: diagramSettings.bgColor,
                borderColor: diagramSettings.borderColor,
                data: dataValues
            }]
        },
        // Configuration options go here
        options: {}
    });
}