import spark.Response;

import static spark.Spark.*;


public class webApp {

    public static void main(String[] args) {

        // Port fix
        port(80);

        // .Set the location to serve static files from:
        staticFiles.location("/web");

        // Serve up the homepage
        get("/index", (request, response) -> {
            response.status(200);
            response.redirect("index.html");
            return "ok";
        });

    }

}
