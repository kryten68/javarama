$(function () {
    // Datepickers
    $('#start').datepicker({
        dateFormat: 'dd.mm.yy',
        prevText: '<i class="fa fa-chevron-left"></i>',
        nextText: '<i class="fa fa-chevron-right"></i>',
        onSelect: function (selectedDate) {
            $('#finish').datepicker('option', 'minDate', selectedDate);
        }
    });
    $('#finish').datepicker({
        dateFormat: 'dd.mm.yy',
        prevText: '<i class="fa fa-chevron-left"></i>',
        nextText: '<i class="fa fa-chevron-right"></i>',
        onSelect: function (selectedDate) {
            $('#start').datepicker('option', 'maxDate', selectedDate);
        }
    });
});

$(document).ready(function() {

    $("#additionalInput").hide();

    $("#processButton").click(function(e){

        e.preventDefault();

        // Get requester name:
        var requesterName = $("#requesterName").val();
        console.log(requesterName);

        // Get business area:
        var businessArea = $("#businessArea").val();
        console.log(businessArea);

        // Get requester Email:
        var requesterEmail = $("#requesterEmail").val();
        console.log(requesterEmail);

        // Get requester Phone:
        var requesterPhone = $("#requesterPhone").val();
        console.log(requesterPhone);

        // Get PM name:
        var projectName = $("#projectName").val();
        console.log(projectName);

        // Get PM name:
        var pmName = $("#pmName").val();
        console.log(pmName);

        // Get PM email:
        var pmPhone = $("#pmPhone").val();
        console.log(pmPhone);

        // Get PM email:
        var pmEmail = $("#pmEmail").val();
        console.log(pmEmail);

        // Get PM deputy:
        var pmDeputy = $("#pmDeputy").val();
        console.log(pmDeputy);

        // Get project start date:
        var start = $("#start").val();
        console.log(start);

        // Get finish date:
        var finish = $("#finish").val();
        console.log(finish);

        // Get narrative
        var aboutProject = $("#aboutProject").val();
        console.log(aboutProject);

        // Get narrative of failure
        var aboutFail = $("#aboutFail").val();
        console.log(aboutFail);

        // Get dependencies
        var dependencies = $("#dependencies").val();
        console.log(dependencies);

        // Get budget
        var budget = $('input[name=budget-radio]:checked').val();
        console.log(budget);

        // Get Oracle
        var oracle = $('input[name=oracle-radio]:checked').val();
        console.log(oracle);

        // Get planview rep name
        var planView = $("#planViewName").val();
        console.log(planView);

        // Get request Type
        var requestType = $("#requestType").val();
        console.log(requestType);

        //var servicesRequested = $("input[name=services]:checked").map(function() {return this.value;}).get().join(",");
        var servicesRequested = $("input[name=services]:checked").map(function() { return this.value;}).get();
        console.log(servicesRequested);

        var formInputs = new Object();
        formInputs.requesterName = requesterName;
        formInputs.businessArea  = businessArea;
        formInputs.requesterEmail = requesterEmail;
        formInputs.requesterPhone = requesterPhone;
        formInputs.projectName = projectName;
        formInputs.pmName = pmName;
        formInputs.pmEmail = pmEmail;
        formInputs.pmPhone = pmPhone;
        formInputs.pmDeputy = pmDeputy;
        formInputs.projectStart = start;
        formInputs.projectFinish = finish;
        formInputs.aboutProject = aboutProject;
        formInputs.aboutFail = aboutFail;
        formInputs.projectDependencies = dependencies;
        formInputs.budget = budget;
        formInputs.oracle = oracle;
        formInputs.planViewName = planView;
        formInputs.requestType = requestType;
        formInputs.servicesRequested = servicesRequested;
        var formInputsJson = JSON.stringify(formInputs);

        $("#additionalInput").slideDown(700);

        $.ajax({
            url: '/qcoeFormSubmission',
            type: 'post',
            data: formInputsJson,
            error: function() {
                console.log(">>> Inside Ajax ID: 001");
                console.log(">>> Error callback has been triggered.");
            },
            success: function(data) {
                //alert("Here is what I got: " + data);
                $("#message").fadeIn(5000);
            }
        });

    });

    $("#hideButton").click(function(e){
        e.preventDefault();
        $("#additionalInput").slideUp(700);

    });
});


