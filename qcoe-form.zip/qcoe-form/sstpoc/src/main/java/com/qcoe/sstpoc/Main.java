package com.qcoe.sstpoc;

import static spark.Spark.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;

public class Main {

    public static void main(String[] args) {

        port(8080);
        Logger logger = LoggerFactory.getLogger("eventLog");

        // .Set the location to serve static files from:
        staticFiles.location("/web");
        init();


        post("/qcoeFormSubmission", (request, response) -> {

            System.out.println("Got: " + request.body() );
            return "pish!";
        });

    }
}
